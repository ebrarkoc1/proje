#include <stdio.h>

void menuGoster();
float bakiyeSorgula(float bakiye);
float cekilecekTutar(float bakiye, float miktar);
float yatirilacakTutar(float bakiye, float miktar);
void islemKaydet(char *islem, float miktar, float yeniBakiye, int sifre);
void sifreDegistir(int *sifre, float bakiye);

int main() {
    int sifre, girilenSifre, secim, denemeHak = 3;
    float bakiye = 5000.0, miktar;

    printf("--- ATM Sistemine Hosgeldiniz ---\n");
    
    printf("\n Lutfen sifre belirleyiniz: ");
    scanf("%d", &sifre);

    while (denemeHak > 0) {
        printf(" Giris yapmak icin sifrenizi giriniz: ");
        scanf("%d", &girilenSifre);

        if (girilenSifre == sifre) {
            printf(" Giris Basarili! Hosgeldiniz.\n");
            break;
        } else {
            denemeHak--;
            printf(" Hatali sifre! Kalan hakkiniz: %d\n", denemeHak);
        }
    }

    if (denemeHak == 0) {
        printf(" Hesabiniz guvenlik nedeniyle bloke olmustur.\n");
        return 0;
    }
    do {
        menuGoster();
        printf(" Seciminiz: ");
        scanf("%d", &secim);

        switch (secim) {
            case 1:
                printf(" Bakiyeniz: %.2f TL\n", bakiyeSorgula(bakiye));
                break;
            case 2:
                printf(" Cekilecek miktar: ");
                scanf("%f", &miktar);
                if (miktar > bakiye) {
                    printf(" Yetersiz bakiye!\n");
                } else {
                    bakiye = cekilecekTutar(bakiye, miktar);
                    islemKaydet("Para Cekme", miktar, bakiye, sifre);
                    printf(" Islem basarili! Yeni bakiyeniz: %.2f TL\n", bakiye);
                }
                break;
            case 3:
                printf(" Yatirilacak miktar: ");
                scanf("%f", &miktar);
                bakiye = yatirilacakTutar(bakiye, miktar);
                islemKaydet("Para Yatirma", miktar, bakiye, sifre);
                printf(" Islem basarili! Yeni bakiyeniz: %.2f TL\n", bakiye);
                break;
            case 4:
                sifreDegistir(&sifre, bakiye);
                break;
            case 5:
                printf(" Cikis yapiliyor. Iyi gunler!\n");
                break;
            default:
                printf(" Gecersiz secim!\n");
        }
    } while(secim!=5);

    return 0; 
}

void menuGoster() {
    printf("\n1. Bakiye Sorgula\n2. Para Cek\n3. Para Yatir\n4. Sifre Degistir\n5. Cikis\n");
    printf("-----------------------\n");
}

float bakiyeSorgula(float bakiye) {
    return bakiye;
}

float cekilecekTutar(float bakiye, float miktar) {
    return bakiye - miktar;
}

float yatirilacakTutar(float bakiye, float miktar) {
    return bakiye + miktar;
}

void sifreDegistir(int *sifre, float bakiye) {
    int eskisifre, yeniSifre;
    printf(" Mevcut sifrenizi giriniz: ");
    scanf("%d", &eskisifre);

    if (eskisifre == *sifre) {
        printf(" Yeni sifrenizi giriniz: ");
        scanf("%d", &yeniSifre);
        *sifre = yeniSifre;

        islemKaydet("Sifre Degistir", 0.0, bakiye, *sifre);

        printf(" Sifreniz basariyla degistirildi ve kaydedildi.\n");
    } else {
        printf(" Hatali sifre! Sifre degistirilemedi.\n");
    }
}   
void islemKaydet(char *islem, float miktar, float yeniBakiye, int sifre) {
    FILE *dosya;
    dosya = fopen("islem_gecmisi.txt", "a");
    if (dosya != NULL) {
        fprintf(dosya, "[Sifre: %d] Islem: %-15s | Miktar: %8.2f | Yeni Bakiye: %8.2f\n", sifre, islem, miktar, yeniBakiye);
        fclose(dosya);
    } else {
        printf(" Islem kaydedilemedi.\n");
    }
}